## Live Link
Hosted in Netlify -> [Smart Home](https://mushfiqs-smart-home.netlify.app/)

## React Router Dom v6.4 
Documentation Link -> [Link](https://reactrouter.com/en/main/start/overview)

## React Bootstrap v2.5.0
Documentation Link -> [Link](https://react-bootstrap.netlify.app/)

## Font Open Sans
Documentation Link -> [Link](https://fonts.google.com/)
